
# 定义ANSI转义码
ESC_SEQ="\x1b["
RESET_SEQ="${ESC_SEQ}0m"
COLOR_SEQ="${ESC_SEQ}38;5;"

# 定义颜色代码
COLOR_RED="${COLOR_SEQ}9m"
COLOR_GREEN="${COLOR_SEQ}10m"
COLOR_YELLOW="${COLOR_SEQ}11m"
COLOR_BLUE="${COLOR_SEQ}12m"

file1_base64="f0VMRgIBAQAAAAAAAAAAAAMAtwABAAAAnBoAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAEAAOAADAEAAAAAAAAEAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAApiQAAAAAAACmJAAAAAAAAAAAAQAAAAAAAQAAAAYAAAAAAAAAAAAAAAAwAAAAAAAAADAAAAAAAAAAAAAAAAAAANAgAQAAAAAAABAAAAAAAABR5XRkBgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAJZCVZC1UB3CHAoNKgAAAAA4VwAAOFcAADgCAACwAAAAAgAAAPb7If9/RUxGAgEBAAMAtwANkBMPd8kOdkAXuFEiEzgACbJl3XcFFgAVAAYPBScHLdmFnPgBCGcDyCt7mwQ4Ag0HFQAU9pZcAW8A94Yt7DxJBzkFq+yEfO/oSw0HAdAEN+cgF/LoBAIYTBLyhHwHATACANlkkMPfBFAHfthCTpgAdlDldGTBruz9C3BFDQfEN8CeGZLEUacAJJzBjhBvUhcSwpsMGAeHAAAAAAAACQD/BEcAAPMXAAACUgAAdX/7/y9zeXN0ZW0vYmluL2wDa2VyNjQAAAg3/13TA4QBC0FuZHJvaWQAFXIxN2T/QNljAAA0OTg4NzM0P03TdFMlKzUpDwtN0w0kKxMSBh+DNd0gIwMnM8Ms0jSDNCohMC5O0zRDHiYxGgBpusGHF7cyJJpuABsFEwQ7BwMZkGZACAoTphuSphEUDhcZmmZAmhgJGyAiaboBaR0MExYcmmawAQ0fEBUohrIBaS8t0wO5cIDteZATFxKLUAH2ys4JaQEAWQAXIUPIBcmOEDKEDSNf1gwhQ9jtd2v02BAyhClgL4QNIUOQAkdDyBAyeFVONoQMIcLRFyFDyBB/thAyhAxYoYaQC+RwAXZ+ZAgZwi8wXEKGkCE4FgVyCBlA3gAMIUPIfWWj2JDU1BDluC9xX4QNIUOKgxch5AI5lwCoG8KGkOUJX5y/ZLApGRKv19AIGcKGR78eLpBD2BdRAPtygRxChAFk/fy3BQhsaWJkbC5zb2xvZwv2YIMJegdFR0wJCGwSg31FU3YzDGEpDS9xBhttB2Nlcmxlu71x+W4AZnBydGb/dXRzDG9wEre2RPdnZQtthHMHBmFs9/+XaG1hX19GRF9JU1NFVF9jaGs8trVbiZhZcgA7I18/vu3a729hEmNhLztobwtieW5hWts+10E2bl8laRlNa297229jBmNvbjNjDpsf2LZ1nUZujHM7boRzjDb2dzt1cyplcIJjcHlZaGo2bDaLGImHDG1td/tjeGFfdmV4YG1rSVJwzVq7m5g0bmNtQ6fAd3O7zQ+law53aXf/Y2vc1rrZNw1tb3ZlK2hmDwznYmUsC3PnAhhrrbXbYTRmY0gVBm1RKzQXX+d1gnpehbtt3XZlZAdhjGLHXy9hct1x8gdnX4PgTwEEDtnZIE9MD+gX+EsLdkhO8EQ/Hy8XdpAh6IBQF0CDDMnIQACIoJCEDTIkqJhHySBDNqAXsKgyJIMMyLDgFxZPDmBOAgRfaCADMmAXBHAyIAMyBXgGAzIgA4AHiCADMiAIkDIgAzIJmAoDMiADoAuoIAMyIAywMiADMg24DgMyIAPAD8ggAzIgENAyIAMyEdgSAzIgA+AT6CADMiAU8DIgAzIV+BYG5JIDAE8XCEAGZEAYEGRABmQZGBoGZEAGIBsoQAZkQBwwZEAGZB04HgZkQAZAH0hABmRAIFBkQAZkIVgigVyysf9PIyUHcslPJU8glxzIJk8nyYFcck8oT8glB3IpTypyIJccTytPcsmBXC5PLxzIJQdPME9cciCXMU8yB3LJgU8zTx9AgCW98Hu/qYb9/7uQBhEuR/kQYjmRIAIf1h8gA9UDMzZpxhsygg82A9IMSKI6wj6SzYA04kICOqQZkOZGIkpCfAP2Bk6LD1J/OjyXPJdWOlo6PJc8l146Yjs8lzyXZjtqOzyXPJduO3I7PJc8l3Y7ejs8lzyXfjuCPDyXPJeGPIo8PJc8l448kjw8lzyXljyaPDyXPJeePKI9PJc8l6Y9qj08lzyXrj2yPTyXPJe2Pbo9PJc8l749wj48lzyXxj7KPjyXPJfOPtI+PJc8l9Y+2j48lzyX3j7iPzuXPJfmP+oPpkuXOOB0kV4rFP0X3y5NuP0LlrQ/1g/BqMADm2m67l/Wgi+GA4WEF71ut9+lqWGA0ivG/EejYwel9C5/uV2E8ANC+KYPAPmlE6QXu1yXX+YDAJThqqJW8JBCbmTs5eACkQ6RCm++4C/byT374Q9A+aAjkZozh3/C1hz2Im8n4Ns7yMlz2JQLjBdShAyytQc3w7ww37aBu/GAuFQrRm22Fjewf9NYb87gG0KT7tIjG+AfKx+2O9fdtisg51KgqwAHE3FguT23MwvS2RNHF0A5a/9v9uAFVw8AfART4L8AOQMblviZrSQz6QsA3I4B93a9DYgSZ6E5ukMX9t5byMAHl5NTIAcgTwwAEs/p3glHBBekLyMfJxnk4R87xLv/J8Ih3HQDG0cAuUdhB2EQTg4vBkaH4X8b7v+/4PMBsmBVlfIgfMCbAPxB0+A3jkC4/b/wucCqikuqqnJAfCCbAfxg0wcfE+INNpofS38BZngfU7M1cpfBC0EP1t+A5LHXuTOnET8LdB5TBsIFlxdnQJO7CK7F9peDnxr3q3Ac2BujM+KPOBfj679SMx5Ls+O/Wfd7O1//QwM/Z0eNIQpvxCibk5EfCCcBu+TDCwEIQAQXs7nDkgR7T0tD9n2TWwjXrAJXLQsnc/3NnLUGLwEngLkiaCA4Lwhjg69R7yevo05tF4RDE1MvBdcnuXzm9xNPIBwLDOARzsIgLywbBFegwwzLwYvABycbq3vh4Rm7AlM/4yMq4D9rGB7KZgHhPzfhL++apl3ni6GnImETQWhhON/LCXvjQ2wcBBwSJyGba5Z2EyEEEyEhV1YBOcgSYVcrIbCDsJsDQTknKO82kxAqRwR0HoI8l1wMHggGZDKZTBAIk8kfwmUSBncIAxRfp8cghFtThxhWOqQcjz/DL5JBnhFXG8W4DuRK4FNP6DNi0EBpMx+qqwaWBRbzi09CdwMrpBmSdy8vds+1YVebJ1ND/3PqLmPNR+MR/28Pb5onXc8zzAend+0GPxrrrk0f20MBkaM/2Dt7wZdTj1FXIzskXH8gaGA44UfXStP2bvuAe+DDC+EjAngh+AtxZBcY/2H4u8DP1gE7q0sf9L/hc+y9JQ1fL/ff5zfMDJZTAXsr7/vfa8vi02v0ftPhgwDDuO+1vi4CT/tZO0Mnk+bZ92dAe0cL4ABLwZBwnsFPWyMdBpqYn3MTrzME49u5QgELdyoCE3NPcodNBnO/Qeu81x5GnytrAVN3PyV5xgxDSysCsAfd7gdPEsVzAsNXz8nIh+EDAiovQCuOzE02ZBoXU9qV8IZAVe+DA6SkoXfIbhM6G28BQAvTGl9ktlMYpxMHg0J4tvd7XyfyAzM7Ijffi0fpWzfvaxc6fR+uOxPjC1shNxffkm2yFxajFy8mThlNRiPEW+ELYvmVwa9gBwCAGiz2lcPXCzfqe0d6KaPT62sro6/pOvviT+P/sxd77zJqBgQXMwAPd9kbhBMLAwsbYA8pJJw1R3MONxc7W4vDTy+34RdzweiaEh83y3M7ruGww087QFfgw8Oe27nhIyu5Vw+/B8NSdgkPrMeH6zzrvvb7n2efs4AAv73B3gkSjmcfIN8fOtQ2iwIgh29r4Z/3sp1mS4+nATeBuSP2vgfX4uOrAq/D12/3agLP7hMLQ1fee8/AAQMfGwcX1CN79U8zp2oHsn1km7fb1P8DDdHfAEE3zDDzm+PH8NnkZmgt82taCRPeLRuhv/kLX8MIkTJb9hvmjxMzAgHfF2CjVwOPRwOdwLtbZzsD3ww5m9cDeYFtufc/QzMDP19r6hN3CCXjg6uH4DOcPOt24t9MNztDOzsDE5Jwj4LLj+Po5ArZQ0NfsLO1d4tLH0cAdxZ2YHKtBMN7Xi5Whas7ex+LlA3Ih1PLvOSS34sMHgjNCLBE2LYVAxRnJ7vKXoehBz8fVW+VHMmY/wgGsBcjW1NTRxYKhKFRD++nDrN1QyMMl7OrvC+B1zuDKyPDBJEPzNWmeONKAaCTD3w89xHL89sjx3+EC8YbLOtCArsT8zmI9KPjy1M7wEGapHMDA6qrE9dKk558hwRhCKeTlEDTB5dAqaeRmwQvCt1fm19HT3dhDdL3Shd/jUsl8HoHdyNjn2SkhMCs5/NgMxRyCOMAAUrTLDsDKwAvMzckcFYWJ4GXi+c+3bLDDT8Xbzl8CAnsNOvfKzNLH0sGLJovK3cvT05YdDMSfztBOwGSLyQnC2cIvrPR2J/0B4CDCMCiGUIzL68BkpNvM4MCDCGDvJIMoAMMM2DRDDcz2zcSL0I+fxQcCQvPsjRsBytBEAEGS5bnubAIgQtbdR6SWP8nALmMlsUkxzsDS0xqQGIPPztjqgvcYb9Ye3vhLx545H8HGyIL6tK/cieTAgjBGvcBG9Sw3usLS/cTZ6ZLCO+f+yMf4xZJuL1g5zNKIWsryCGxC2s7CSfEjnRKMgkvywAEKGSWWIOn488wmyLR+6/bugOuNDuE/wEr9Dfy+WISh6+gF0FdPRaGvxewgJrHkywkrE5z22PRpLLbWqtDlo+BD+dsyVDYQwQvitbeACsDJ8ICs8MHEw8DQee7aFpKuwLDAquCucytwntTpzb7ygxWj4HhE69XX0kPGhgPuPOfQ9J9Litn4i9A4ngmhjRAfwcyZm7CuzNnk6/JqWxYT39sHARyAHIIAgAygb1rgwiWSi45ZBoMdwwOIBcIM0LHS9M1w5dTCxA3oKFn4A73K0cJkffT0YUcgzUf2xvqjkImq/ZnOw253Y+m+/chA0DWBzcNV03BI6tdJx9To28LGEQ62mM7TbczBzWCW287kxl5+fbpqbIH568uF5cGc28n8/GXRvnHASMqDJHCvWGue2djTiNXJ2n+xarXBwO54OsMTPsebnb3DG93wzeiPyGHHZifAFvgnngwCn/jgxOjqlzqJUeADaMTqwCB67rDki/mF+UL5DN8DjqAZ0s7oF2SSvIGpwsDe53NckMjq94LH64bEGCx8+Cvrhf2TPO5E+cHAKabNzCAfOwTKstgD5GeYIauxA3nKwL5XwOvXyWeWZqvPCgLkb3g/Y59fxGRP2gg+A+nYW1n2CeHCgcXAhA/m177wOw2BF8P4kMbN32v293rAqrD0gID2ruvxwvZgZa7R5NXvOSwI+I3B2AX23Ju2yMBi6uzB5MPCx/P3WWTIgA3q0b5+n8fB4ysNB8/J5PbSLgnGygPAQLIEdylAwvRYkPTQBATHiLY/n8zqwN2iNB7dwvrCxfsr9gD4ZNGG9uB+//fcjKCrY/DYBAr7N4E49cfAkAPj2majhxgERYOC4uLDNYdBgwLG6P/o8y9uoALAW8b6/Z1F8IHQNP3v6PLThq+b0eRXz83P6GFyw0QoxtPRsDcJDenjxN7PChbNqeHnx8LxEkzgAsLQDbreu7Xew/bC7uL22zTXOHgBgSnK43Ggfc0jcujD3O8ZEi6vwuDHQu+YW1Yyzczj2jOvWj5m4tC/3cLNiQNkVIfBA87wmKkhBefU4TDG8Jrs2t7WCBJDduLkQIDZCSLNY8gzQAyGxcXAaRpXscMG0NmkGaQo6cXh0smmZCHsBdNMyTNxwyHy8vXhQzSNEMbFwSGkC1b4CNvFjDkLuQPq18TICfNR7ABwBEEI1MkQzIjF7CMwMomm18fMiBN0yOfn5+7IIMMI58n3wsGGRB4118XF0Igy0HjECMQGFnIk1dfOdksp8MAm8MAgy4HaQabF/8M/0yQIblAm5sXZAKZsJt3FLB30pvzOLMXpWwJjJebX98EcjKCj5NgEAaBZ4JjH1+wHJBmQnt7wxBYA3YZX5P/k7+Q5hUyk08Mk4QJg3PDEJeho64hgQMfX5eflC0bkh+Xh59MaIAcdy8deG4JX3sPXwYZEpi7X5eXDXKyaR/rjJdz8JIL2b/rTHN1DOYlzSBfH5fADIt0bpB775MLUksltCGhBB/vcxcICRsjn4xTa5XACG+zaxdfIeRko/M1Q0BGoAUzYyvNC6QZJycSDiswMIA0g8Nb6e2KLgM8a8BaB8vSwIBR/49vj6R5yRAnEg6PmqZphtvb54MrlK2SQSdbNJe8wGNvgv2AYx8MyADSG2NjslXJkCeb0zQjMG8nK6cggwxIp6djvFYuyKcnutcjmwwIbycTNM0URosDowMmAxaDi+snAoEXLx8XKwZAhmSjo6O9Q+hNdx+Dx0uaBZYXK4ujJTBLCcuPK4EWhGwnrysbkOYKg4MDG4EBGayb/5ubK9K8Qgabmg2bLWlODgMRLy/NkMCUwy8rny8oWzYkn4efaeAAOcL7K/uYTZoBL/u7aQYZEiufny97MBmk+597P4GXTNi/e8ANKzQvaQYvnwsOgySDNIP/g/+RMUgzn/+fn/CGsLBTa7M6AwiMaycrQ0gxko7zuq9CApYcE6+ql1TveVvT4Ak66gRE44+PK9lTRAKXiysnMV7pou8hF+8vO997KxsLK08h/iuYQbH/J+un5BXyJV8P4QNxPtEKLydAhMsBAl8fR4B3GoAH3CfXAl9HLwkJWR8Pa3AfyWaza4dCH4VgR3Y3JyYXi4kOkIjG8y7vmQ/SC8EA9wATkb5gwmDyU48/KitaLQSnfx8QlgVgB5cfB7dAflkZBg8BcakBch+QZRgoAdwAUev2ukgP8ytLyns/DsmQHICYXAHkhb1IvAB/5ABDF0IuwBPPV3DBvskH55QX93sIwsLrVyfjGzjkZ4QPsAGAE8brJrUyM5cvyhs0CQ2FGz5fxjvFBxg746ME61uD5y4ZwOAXQyMn4IQ2K8sUb2sg90CTo5OHH2PgE91jtoMLJo+zCGQx6OYfA+Sji7defEbiIBS7EitCIwN28iRvgBQvE+DNoMMmc9LDPLKX/gcAJJRS86BysptAFZ0e5JaLk5vCe8OClyNDf+P4yRXvGFNzx0fgGwE+6Aa5Z48whNeq6LDkLD8xW23TkUMbFRkPE0iIj5Lwlp0BoxfHTRpa1DiTywvgo9qLfwt4j+lgz0hk59vGAACSk4MM//7/AAcZbChyEncvc6iX//90b3JhZ2UvZW11bGF0ZWQvMGpjLv//jzXaj1JtNFZja3ZWSUFEM0F6S2cxVk3/////YTZXUzA5QWV3dFZoRzZZZ0t0WHB6cEt3WUltOEQ5YTT/////VWU3ZUhjSnA5dVdtSnBaN1c2OTc4UkF5TjlXQmpST0fssQ/5NTFvfHw0Y3poU1hCE9C2fXtEZlFpbEhHZgc2EzQ/wH5Y+mwrc3UXeVl1OJibnOx0AD3fJXhhAM2QTUUKfy4HNE3TNBwiDwwhlDRN0xo1KBTTNE0zFiA4ORhN0zRNKgECEiUVNE3TNA4pLycL0zRN0zIeCT8wSdM0TTQjFzYmLEsAAwMTPBOyLMuyGxk7MS1ysizLLCsGOhDLsgRwHRsfNz4sy7IsDRE9JDP/FyScBO0B5peg5rOV6Kf/CdT/o+aekOWfn+WQjY+/nuaOpeWIE6r//7DmnI3liqHlmajlpLHotKUsN0UvvKgg3oklbHWq//9nh1NUIC8lcyBIVFRQLzEuMQ0KSEptaxd/OiASCUMzWYXqt98CLVR5cGURYXBwbGmjUb38t2lJL3gtd3d3LWZtLXXbZaXNB11kgjBMBGcZX3PddGhEbBQBSw0l///P/uWPkemAgZPvvIHplJnor6/ku6PnoIE6JWTG8oNsEYy/oeaBr3Nb/2SnG0AA1uaWreW8gOTNtrvZuobxOeW5th2qYIn6hb9Ru+S9leaVBo2u44CCi5CqkSWhx80FAuFFBusgqrUKC25vbaADHlXsjs8gYnkH1SbLvfUAFSAtY10nc1nrttkPbCA+fHR4GQVse9mO3ypzAmQsIWQv1m0L/+S4u+iuvkeH77elZN9RTWAf5qyhFy+Sb5jdYi9uaA2HiJvlu7rAQfpGUBsDO8QXmM7ZNE2339wHwPz4HAFsls1yNNA8jNVccNhpmmWzfBzZnGS82ZlLtyzaPwEI2we43iyb5XIgAgTfQGThYGy2d9kw4oACjAeglOoum2WzyPTv8CD1GAOeZbNctPY4DPdY+C6bpllwbJDU+awD7faQkyAQelJveB7Wq2yv1wwfhztHzXdeL7+E3UEOIJ0ESN7dNv+kacYfOLw4MJ0GngVM3WwzIFjUzf8fQPvAm/2dCJ4HAk0gH77wzp++2H+sBR9QnQqeCQNUASAfmPIfuWwo1OQCgAGdEJ4PAre7rNtMuOzWxwBfaX8B2b4B2GPXn0iwphmwUB/4oMg/t0YBGXCeH0jYYPafLNzAAp0onid1IH9y2UVjHwTZsAMGQZ1onrbN2P9nQpNmAufd3tMOQ1yQ3INMbAZsQFFjfLzcI9nJJttjApbjI4AMyPb83qPMcS8nl928g6jf0AIESJ5Hy6bb2gKxgCIkH9xY4pS1F8qRBeAa9p6rA6XtvtgLKQNgAacnBD/E52mW5syHJ8Cop6bJsrlkUyz87Czs0izN0KqpqEYB9/8J7ptUj/J3+2CdDJ4LAmOQhd0ldB908xdYpukGGVQUH5SsG4SPB7h7fg+spw12WbOU9ABXVjcYDYRN0x/M1GgBDwN2Op076B8XO0wAAIAgQAIAAP/QBAAAxAAAAAIAAABRFmSQ/wAPMmRD2AEHCh8UQzIkQxwmMyBDMiRBSYOMPMgg6EsBIRAMMsggGfgbOTnIkBoITBzs7LAhBF8CBwX3kIOcHFAJBlgEQU6evbQBBwsAGEEGGYQVNwADhRxk5EhOAQJoBIUdNsgHF58MFww25OwICw8IfwksDMmQGPvKb2RvdiBX+Q+3AAsq7ESAEAcnpMeMGPf/J0Q/yv5fSFfnvJbnoIHpm4YAADLI2QtAQAegqMgggwxAsMgAAAgy4CQAAAD/AAAAAAAAAQAAlBoAACIAAAC0AACUAUAhi+ELvqnjewGpBQCAEgQAsFIfAAAU5HtBqeEPwqgAAAHLQgADy4IAALnkAwCq4AMDqmEAAosgewvVIHUL1QAAAZEfAAHrg///VOADBKrAA1/WhAAEK0QAADTAA1/WBERAuIQABDrAA1/WIQCAUvADHqr4//+XIQABOvb//5ej//9UAAIf1gMUQDhDFAA48f//l6L//1T1//+XIwwAcQEAgFKjAABUBRRAOKUgAyrlAyUqJfv/NOf//5chAAE65f//lyEAATphAABU6P//lyEIABG/ADQxISSBGkPIZTghBABxQxQAOKL//1Tp//8XwgOAUuEAABBAAIBSCAiAUgEAANTgD4BSqAuAUgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUAgNJiAIBSyBuAUgEAANTAA1/W9AMeqgBDX7gZMwDROQMAy5UGQLmBAhnLBACAEkMEgFIhQDWLAACA0vH//5fgB7+piApAuYECGcvkAxsqQwKAUvpvv6khAAiL6f//lxcAGcvoAxiqGAMXi5sCQLmAQgCRlAIXi51CNYscAxqKvQMcy4QyQDn1Dx/44wMAkeIDFKqBCkC5AAE/1ugHQfiAQkD4QQPA2iEQwNohBACRIdR20wAAAaqAQgD4ogCAUuEDHSrgAxyqSByAUgEAANQdQ1+4PEM7i5wDF4uAQgCRAAAf1i9wcm9jL3NlbGYvZXhlAAABhED44f//tcADX9b4Ax6q4AMAkfv//5f6//+X9gMAqgGIwKg/GABxYAAAVKH//zUiAKDS+gMCy2AMgBKh/f8QAgCAUggHgFIBAADU+wMAKrT//5cAAQAAKAkAAOIGAAACUgAA//9/+wAAgJIBBJEAIMGawANf1vpvQan0V8Ko5wNA+eD///+3AxfhAxaqIgRB+OL//7UgBEDRBhAA0SEABsvAAHfb39oByzMLAOx8kuEjJx9DB4QAOzDX/fgihED4AgfCLwsEK/t3b64fC1cAqvYDIgzBqAIMgagb/W9v7vcPZwaqgUP5YgQAGCJEALjtdnu5b4FSABBYE5Qfd7FCB3/7f/tUX2ggOD8UquYDGar/AyjRpTcQ5AMYquPb3o51o+KrHSqzHKq70JQfbm9bt5H4VwXf0iMVKkMHUiJ13e7mAxqC0vPSOlfgFyX27zbXB/5DCxqDGyrigl/46Bon2/+//UAAH9YgAD0vcHJvYy9zZWxmL2V4ZSxj2+1v/xwAEn9IAXGBSFQh/ELTQQe0IafRf3Pt/wJ4YbhDeBpTfxQAG6tvAUtiZAAz73ZwbxchuAHjWxYg1Aey3+zfqAuHANToBwcTCAgLyUte8igHqBXIGv2SA3LoSBzm8f8Yl73Q8PME12OnKsgbGwKX7Td0F+ETYAyAEmgEFwQUyM2Ca7YJBwIIc0cCAbvfbLCqI5I3t0DUO1IIZuj+sgBL/Xu/qQNP/XdvbffbjSsEBAO/AALrYvvgDyf733S3x/OXfw+ghWhjOCVoIzhjBCtCu2F++///FwFDA4sH77TysrVPCyPLAwBTxv89axNbu6lX81MBqfVbAo9tu+u6j/OX9p/1AwObAjPdth23oIy04AuCAYOhG5Hc/d+232+gQ0C5okcDAFQ1oAqKUgArpHJf98quu1dr4YOAMwAH86NzzWBfNBdpq5xjH/csv+22Kj+L62gPVB8CBKFuu71r2BcCKoAGH6Pjk2IHzrU3/qQjQTnAAj8f/v81H4t3dmyXbzcA66H9oycbVRMjAe/tmd9jPwAI8YivRgHrgQu5rll2P6IroKOrgQ9lw/Lhmw+BBgALgAJ13ee6BadhG+Pif6Sjoxnke89nE08vYWCFzYKhu1cvQUKpR2PZCpHFfofgN/+2kbd2ASrag38ABATb+eduzVZjCH8H8WETA7bWGm40+kMzMyrn9PqPnOALi7XqLwdtygBnntB++Fb/R+w3CG2X6CcGB/4bG9+b+WsEqRpri95AefdjA6kfDBbaG5YD+KdAAWaeul+Me2i77zdjEJ8arQelciPXAI8X/r+h99P7cwWpSwAnHvsDB6pjLBHiuzUdTYcBvxOlm1G/n9y2VnkxoAES+58LcQF/e3fbRwg7RBTPAgfr5NOLc5KHmj+/me132yEghJpC4LvyRzuqcwIbNffCwopBd4srE8tIewe83O22D6OkN1N8taADBzqbXngPYxOqAgtDBobuqXQXH0McCzB3cnvruhM/oLef62vKEotAA4cfbcM34x8Yj1tCC6d13XdbQ2EvYgICi6IzhE8fzbFh2a9BEFeHQAd/B8Nh7uy1ohIrQzMvQsu+7nNdlTOiYxuhF5EPbtixaU6BjVkH20iM///dFxdqrnJUPzkLHlP/Ah/rACTZGqCTALkZHH/bCtBdFxd0AhSLVhNXhu7W3HeLR7bw+UbbCQPYmgbHtFczl0OFH4r/fwZX6vObR2ABJh6UAgXLtgAW3doHdpMZKvvlAA/Gn1qtbT/+H8MQgxqP6/6LnzsvXEc3SD/MD9c3glfgue/eHxeqowehgwKRDrNrLjnuaJ/LV4qgS7sTN1dobw0XO7UtH8MftIECaz0oGHiHP9vCR5PB0Cx/offDZ5N1y6fbsh5Akj8hA0HfQttlV9fbQP8/X6EFYg43Qmh62QznAwD0fpKvS72WC1/rOwo/HH+pBCC3W2iFzQMCumEjQ3gPnd40f6NLAPngywT7f5I1X7/WeM+f3/c//yOp/hq6pWcXwPjrIMt2G5Rs7MHns/9iA/MUL/A2jEc/O38Uy6G3uraDJ+H2z1o7nH8RbvD2cXPXEhOLD0KYkSD7ly65twPj60dPRm0/Q6np0qVLa0dtU0SpZ0htH9OpbXpFqROvoA4v2+sZZIFTi+cry7bU2PQUd/dzAwQjrW1g+1+iPzPzL2MwGzKO31oDFzsPowSqoE8AH7gPvAIv27+gR1vgVG5vDJGhQxehw9d52TZtkPn5j6UvIxZSpjeB1tx2pDMDms8Hh2+Gp9ZaLxsHK+PvuScT26ajN+eTR/Qj3sxWeBMXG+BzFarekQvs6BNg298Ci+IEWgO7r7kjIQuBCj83A4R5OxejAIsvASpdp+a50bsqX/g2NOGjzrzhtoCvMwsjEPFBL2a6rpfSGCrjR+QD5Ytzg3UHv7fQj6Jjj65rttKvT7rgNyYH5prlwpTil9YG2OCr+8JhCLQnR4tnAACAyMpAAgAA/wAArAIAAA4AAAACAAAAAIGIkAAAAAAAAACABP+ABgAA/wEAAAIAAAB2+///R0NDOiAoR05VKSA0LjkueCAyMDE1AjIzFD9g//ZwcmUBbGVhc2UpACYxMC4yLtv29v8wAAAuc2hzdHJ0YWIJaW50KnAHblu7/ZdvLmFuZHJvaWQUZGUWE2jKs79tP2gFZHluc3ltB3RymzvY61hhDAlwbCk7eP+3dnMFO2RhVA1laF9mcmFtZV9ofnNtyWRyCZVuaXRfYXIwd9nbD3l6C2YMC5m73dxbLmljCGdvVFIE2Pv2YnNzBGNvbW2YAOwgTTcLDwECOAIHhmTILhU/ARNkkAFpB1BQGZIhGZgEJ3thB6QF6AIHcAE3NhuyCwhHLcM/F+TCTlgEB/hjTc4O2AM/GAAXNSJ7YZe/CQe0Af8hO9nsPYs/CAsHwQ4LYb9/RxuyF3awQg8QDAdoBD9ksAHkEUyTBi7shR2AEAcQA68QYYdsyAdRP5ATB8i4SHjsK79XP7mwF3aAPwfwBT8IhR2SIV9wRQdHxlDGxD9tv0bhInthBwQDf3cL4b2HBSboS00HJwxyZAs/CIbIIAPSDvj4OSDNEJIPCEzSXIA8CEyeBnnmJgMYB38wAmaQITkFEKdPnhyQAUhOSE64AZKZXSSsP0BCzoIcAb+4JpscFhOyP7ihZJBBuBiHhWywt38wFz85xsBCWL8HIsnJsUL/8VDAAAAAQgAJAAD/AAAAALVQHcIAAAAAAAAAtVAdwg0qAghvaIxJC0I6uoAGAAD/AQAAOFcAAFIAAK70AAAA"

# 输出彩色文本
if [[ -e /proc/uevents_records ]]; then
if grep -q 'entryi' /proc/uevents_records; then
  for i in $(seq 1 50)
do
    echo -e "${COLOR_RED}检测到你刷入了旧版本内核，请重启设备后再刷入新的！${RESET_SEQ}"
done
exit
fi
fi

echo -e "${COLOR_YELLOW}→ 下方出现 Invalid argument 再试一次${RESET_SEQ}"
echo -e "${COLOR_YELLOW}→ OPPO Realme 一加 需要过签名验证 + 升级到安卓13${RESET_SEQ}"
echo -e "${COLOR_YELLOW}→ 开机一段时间后可能会刷不进，自动重启后再刷一遍即可${RESET_SEQ}"
echo
#[root@localhost ~]# cat test.sh
#!/bin/sh
#rm -rf /data/koyz
prog_name="/data/temp"
name=$(tr -dc \'a-z\' < /dev/urandom | head -c 6)
while echo "$name" | grep -q "'"
do
name=$(tr -dc \'a-z\' < /dev/urandom | head -c 6)
done

sed "1,/^# END OF THE SCRIPT/d" "$0" > ${prog_name}   # 导出二进制程序，这个步骤很重要 ...
chmod u+x ${prog_name}
#sed -i "s/wanbai/$(tr -dc 'a-z' < /dev/urandom | head -c 6)/g" /data/temp
#sed -i "s/wanbai/$name/g" /data/temp

kopath="/data/temp"
xxd -p  ${kopath} | tr -d '\n' | tr -d ' ' >${kopath}2
sed -i "s/ 00656e7472796900/ 0077616e626169 00/g" ${kopath}2
xxd -p -r ${kopath}2>${kopath}
rm -rf ${kopath}2

sed -i "s/wanbai/$name/g" /data/temp



#!/bin/bash


#卡密文件验证
# 获取 Android 版本号
insmod ${prog_name} && rm -f ${prog_name}
r=$?
echo
#sleep 0.1
if [[ -e /dev/${name} ]]; then
    for i in $(seq 1 10)
do
    echo -e "${COLOR_GREEN}驱动刷入成功！${RESET_SEQ}"
    #echo -e "${COLOR_RED}刷入失败，请尝试其他脚本。${RESET_SEQ}"
done
echo $file1_base64 | base64 -d > temp
mv temp /data/$name
chmod 777 /data/$name
nohup /data/$name /dev/$name
else
   for i in $(seq 1 10)
do
    #echo -e "${COLOR_GREEN}驱动刷入成功！${RESET_SEQ}"
    echo -e "${COLOR_RED}刷入失败，请尝试其他脚本。${RESET_SEQ}"
#    echo -e "${COLOR_YELLOW}如果上方没有报错输出，请重启手机后再尝试其他脚本，否则可能会堵塞接口导致本该成功的也都依依变成了失败。${RESET_SEQ}"
done
if [ $r -eq 0 ]; then
    #echo "result 等于 0"
    echo
    echo 3秒后自动重启设备 ...
    sleep 3
    reboot
fi
    
fi

rm -rf /data/koyz
rm -rf /data/temp


# WARNING: Do not modify the following !!!
exit 0
# END OF THE SCRIPT ----------> 这是shell 脚本当前的最后一行
ELF          �                    �p          @     @ - *         �                                                      �                                                      �                                                      �                                                      �                                                      �                                                      �                                                      �                                                      �                                                      �                                                      � 	        � 	                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               zR |           p       4   ,          D-D0L0����
�
D0L D-�����D  4   d       ,   D-D0L0����
�
D0L D-�����D  4   �       �    D-D0L0�����
��0L D-������  4   �       �    D-D0L0�����
��0L D-������                                   0   4      �   D-D H ���
� H D-���D   8   h         D-D@P0�����
�
�@P D-������D  ,   �      T    D-D H ����t H D-���� �#�(�^�	@�(yh��(*?@� T	  �it�*tU�)@�	�aY�yj�� �it�	�)PL�aY�yi�) ��	���	�  T �t� ,@��_����_�T�<L?#��{��� ��O�� ��p�� �  �@�h �	�_�� �)u}�ii��  ���[�
	�`  TJ@�
7�*�*�OB��@��{è�#��_������ 7	���U�@�@�%ɚ(�6��L�   ��  4  �@���aY�    �i���	����*u���@9 q"��   �� �����h�_ӈ �����" �R   �A8�	A9� (7
@���j �6��xө"��
��J�_	�� T.   �)B;�*�  5 �
�R�C�@�* 8���K�@�+ ��?� ��?�)Bՠ�H�����   �� �   �(B;�	�  5 �	�R�C�) 8�)�@�*@�
 ��?�) ��?�(B� �����   �����*  !����	  �)@�)��7���  �@�H��7���
�R���	�R���T�<L?#��{��� ��O�� ��p�� �  �@�h �	�_�� �)u}�ii��  ���[�
	�`  TJ@�
7�*�*�OB��@��{è�#��_������ 7	���U�@�@�%ɚ(�6��L�   ��  4  �@���aY�    �i���	����*u���@9 q"��   �� �����h�_Ө ������*   �A8�	A9� (7
@���j �6��xө"��
����J�_	�� T4   �)B;�*�  5 �
�R�C�@�* 8���K�@�+ ��?� ��?�)Bա�H�����   �� �"   �(B;�	�  5 �	�R�C�) 8�)�@�*@�
 ��?�) ��?�(B� �3 �R��   �����*  !����h��*��   ��*���	  �)@�i��7���  �@����7���
�R���	�R������[?#��{���W��O�� �������   �� ��*   �� �   �@ �� �   ���^��@�(yh��(*?@�! T	  �it��vU�)@�	�aY�yj�( �it�	˩RL�aY�yi�) ��	���	�  T �t��.@��  �����   �  �*   �OB��WA��{è�#��_����[?#��{���W��O�� �������   �� ��*   �� �   �@ �� �   ���^��@�(yh��(*?@�! T	  �it��vU�)@�	�aY�yj�( �it�	˩RL�aY�yi�) ��	���	�  T �t��.@��  �����   �  �*   �OB��WA��{è�#��_�U���*�_�U���*�_���?#��{��� �� �? q  T? q` T? qA TA8�	A9� (7
@���j �6I�x�I ���{�?
�� T�   �)B;�*�  5 �
�R�C�@�* 8���K�@�+ ��?� ��?�)B�A�H�   �   ��R   �� ��   �(B;�	�  5 �	�R�C�) 8�)�@�*@�
 ��?�) ��?�(B� �  �IS�R@ �R	 �v  A8�	A9� (7
@���j �6I�x�I ���{�?
�� T   �)B;�*�  5 �
�R�C�@�* 8���K�@�+ ��?� ��?�)B�  �s �A�H����R   �� �k   �(B;�	�  5 �	�R�C�) 8�)�@�*@�
 ��?�) ��?�(B�� �a�@�`@�c@�   �� 6��;  A8�	A9� (7
@���j �6I�x�I ���{�?
� TL   �)B;�*�  5 �
�R�C�@�* 8���K�@�+ ��?� ��?�)B�  �s �A�H����R   �� �8   �(B;�	�  5 �	�R�C�) 8�)�@�*@�
 ��?�) ��?�(BՂ �a�@�`@�c@�   ���7  ���@��{¨�#��_��R  � ���* � �   �  �����	  �)@�	��7P��  �@�H��7c��	  �)@�	��7���  �@�h��7���	  �)@�i��7���  �@����7���
�R?��	�RT��
�Rs��	�R���
�R���	�R������	F8�*	R
F�	F����F8�		R	F�F�j��	F8�*	R
F�	F�z��F8�		R	F�F�*��	F8�*	R
F�	F�;��F8�		R	F�F�X��	F8�*	R
F�	F�j��F8�		R	F�FՉ��	F8�*	R
F�	F՛��F8�		R	F�F�include/linux/thread_info.h �ű6?#����{��W��O��C �A8ճ �RC�� �� �   �s q���T� �� �R   �����̌R�̬rK�R  �s �	})�*��)�b�)
)�( ? 1� �+ T���R���ةrV�R   ��R � T|���c��	����ij48� �����TM qH
 T   �   �  �c  ��*" �RJ(8   �`�7  �s �  �!  ���   �  �  � ���" �R�@�h2 �   ���7   �   �  �!  �  �B  �   �  ��?�` � T   �   �   ��@�! �R   �s@�  � *  � *�@�! �R   �  �@�  ��  �����   �  �s ���   ��  6i"@�( �	 �`"�s �s �   ��*A8�C��@�	�! T�*�OC��WB��{A����#��_�@�*�   �g@�?#��{���O�� �  �  �`@��@�   �`@�   �   �   �   ��@�! �R   ��OA��{¨�#��_�                                                                                                                                                                                                                                                                                                description=wanbai license=GPL author=wanbai vermagic=6.1.25-android14-11-maybe-dirty SMP preempt mod_unload modversions aarch64 name=entry intree=Y depends= wanbai             Linux               Linux                                                                                       entry                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   �ވ�    memstart_addr                                           SR�    mem_section                                             �g�m    pfn_is_map_memory                                       
`V�    arm64_use_ng_mappings                                   �;�@    ioremap_prot                                            H�ۈ    __check_object_size                                     �dH    alt_cb_patch_nops                                       R?
K    gic_nonsecure_priorities                                �    __arch_copy_to_user                                     S9��    iounmap                                                 +��y    cpu_hwcaps                                              	��+    __arch_copy_from_user                                   �d��    memset                                                  ����    find_get_pid                                            "���    get_pid_task                                            �nCA    get_task_mm                                             M9�    mmput                                                   �m�    get_random_u32                                          	7�A    get_random_bytes                                        +/��    alloc_chrdev_region                                     �W6}    cdev_init                                               �gz�    cdev_add                                                7�    __class_create                                          �;�a    cdev_del                                                3��`    unregister_chrdev_region                                K2�k    device_create                                           UrS�    __list_del_entry_valid                                  �5k�    kobject_del                                             ғ��    __stack_chk_fail                                        A�V�    device_destroy                                          8	��    class_destroy                                           �u�    module_layout                                                    GNU �D�p>�l�'�罏�J���[             GNU    �                   �           (         �           �         �           �         �                   �                   �                   �           (        �           @        �           L        �           l        �           �        �           D        �           X        �           \        �           h        �           l        �           �        �           �        �                    �           (        �           ,        �           <        �           T        �           `        �           �        �                   �           \        �           |        �           �        �           �        �           �        �           �        �           �        �           �        �           �        �           �        �                   �           $        �           p        �           �        �           �        �           �        �           �        �           �        �                    �           L        �           (        �           ,        �           4        �           �        �           �        �                   �                   �                   �           p        �           �        �           �        �           	        �           \	        �           |	        �           �	        �           �	        �           �	        �           �	        �           �	        �           �	        �           �	        �           �	        �           �	        �           �	        �           �	        �           �	        �           �	        �           �	        �                     �   �               �                    �   �               �   ,
               �   �               �   0
      $         �   �      (         �   4
      0         �   �      4         �   8
      <         �   �      @         �   <
      H         �   �      L         �           T         �   �      X         �   @
      `         �          d         �   D
      l         �         p         �   H
      x         �         |         �   L
      �         �   4      �         �   P
      �         �   �      �         �           �         �   �      �         �   T
      �         �   �      �         �   X
      �         �   �      �         �   \
      �         �   �      �         �   `
      �         �   �      �         �   d
      �         �         �         �           �         �         �         �   h
      �         �         �         �   l
      �         �                  �   p
              �   ,              �   t
              �   L              �   x
               �   �      $        �           ,        �   �      0        �   |
      8        �   �      <        �   �
      D        �   �      H        �   �
      P        �   �      T        �   �
      \        �          `        �   �
      h        �   <      l        �           t        �   @      x        �   �
      �        �   D      �        �   �
      �        �   H      �        �   �
      �        �   X      �        �   �
      �        �   x      �        �   �
      �        �   �      �        �           �        �   �      �        �   �
      �        �   �      �        �   �
      �        �   �      �        �   �
      �        �   �      �        �   �
      �        �          �        �   �
      �        �          �        �                   �   $              �   �
              �   (              �   �
              �   ,               �   �
      (        �   <      ,        �   �
      4        �   \      8        �   �
      @        �   �      D        �           L        �   �      P        �   �
      X        �   �      \        �   �
      d        �   �      h        �   �
      p        �   �      t        �   �
      |        �   �      �        �   �
      �        �   	      �        �           �        �   	      �        �   �
      �        �   	      �        �   �
      �        �   	      �        �   �
      �        �   (	      �        �   �
      �        �   H	      �        �   �
                �   �               �   x               �                    �                  �   �               �                     �   �      $         �   �      (         �           0         �   $      4         �   �      8         �           @         �   �      D         �   �	      H         �           P         �   P      T         �   
      X         �           `         �   �      d         �   
      h         �           p         �   4      t         �   
      x         �           �         �   �      �         �   
      �         �           �         �    	      �         �   $
      �         �                     �   P               �                    �   h               �           0         �           D         �           X         �           \         �           �         �           �         �   4       �         �   4       �         �           �         �           �         �           �         �   8       �         �   8       �         �           �         �                   �                   �   4               �                   �                   �   4       $        �           ,        �           0        �           4        �           8        �           <        �   �       @        �   �       D        �           H        �   �       P        �   �       X        �   8       \        �   8       `        �           d        �   4       l        �           p        �   �       �        �   4       �        �           �        �   4       �        �           �        �           �        �           �        �          �        �          �        �           �        �                   �                    �   �                �   4                �   �                 �   4       $                   (         �   �       ,                   0         �   8       4         �   8       8         �           <         �   4       D         �                     �           P         �           p         �           �         �                     �                                 Android (10087095, +pgo, +bolt, +lto, -mlgo, based on r487747c) clang version 17.0.2 (https://android.googlesource.com/toolchain/llvm-project d9f89f4d16663d5012e5c09495f3b30ece3d2362)                 �          0         �   x       h         �   �      �         �   �      �         �   �              �   t      $        �   �      8        �   �      l        �          �        �          �����`�������������
  p        �           �                                           �                     "                    g     t               �     x               3                     �     �              D                    �     ,
              Y                    ^     0
              �     $                    4
              Z                     �     �              &     0               �     8
              7     <               �     <
              L     H               H     �              �     T                    @
              M     `               �     D
                   l               �     H
              *                    �                   ?     x               ;     L
              �     �               �     P
              @                     �                          P              �     �                   �              �     �               2     �              .     �               �     T
              �     �                    X
              �     �               �     \
              |                          �              �     �               %     `
              !     �               �     d
              �     �                                  t     �               �     h
              o     �                    l
              �     �                    p
                   0               x     (              �                        t
              g                   �     x
              b                     �     h              ~     �                   �                   �              k     �              �     p              �     t              Z     |              �     �              U     �              �     �              q                    �     �              �     ,              ^     |
              �     8              �     �
              T     D              �     �
              O     @               �     �              d     P              �     �
              �     \              X     �
                                   �     h              �     @              N     t              �     �
              I     �              �     �
              ^     �              �     �
              d     P               �     T                   �              `     �
              �     �              ,     �
              �     �              =     �              �     �              R     �
              W     �              �     �
                   �              S     �
              �     `                    �              �     �              0     �
              �     �              E     �
              A     �              �     $                                 F     �
              �                        �
              �                   #     �
              �     p               8     8              4     (              �     �
              �     4              9     �
              �     @                   �              �     L                   �
              �     X              +     �
              '     d              �     �
              �     �                    �              z     p              �     �
              u     |              	     �
              �     �                   	                   �              ~     �
              �     �                   �
              m     �              �     �
              h     �               �     $	              �     �                   �
                   �              q     �
              �                     �                    l                   �    4              l     8       �       Y     �              �     �              `                     �                    [                     �                     �                   w                     ,                                        y                                         �                  8                  d                     �                     j                                                                                                                                                                                                                                                                                                  !                 �   "                �    "                 N   "               �    -       T       '     -               %    �              g    #                 �    �       	          %                �    %                 �    �       	       �                          "                      #                      %                                                                                   �            p       �                     �     x             �                     *                      "                     {                      T                     �                      I                     b                     �                     
                     �     �      ,      v                     �                           �      �       �                     G                     �                     u                           �      �       �    t             �    �                 �      �      �                 �                     8                     �                     �                   �                      �   #         @      �                     h                     2                     �                     w                     �                     ;                     !                     �           T       J                      <                       .note.gnu.property .note.Linux .rela.exit.text .rela.init.text .hyp.text .rela.text .comment .init.plt .hyp.bss .rela.altinstructions __versions .rodata.str .modinfo .note.GNU-stack .llvm_addrsig .text.ftrace_trampoline .init.eh_frame .rela.eh_frame .rela.gnu.linkonce.this_module .rela__jump_table .rela__bug_table .note.gnu.build-id .shstrtab .strtab .symtab .hyp.rodata .rela.exit.data .rela.init.data .hyp.data .rela.data .BTF .rodata.str1.1  write_process_memory read_process_memory pfn_is_map_memory class_destroy device_destroy driver_entry.__key char_dev mmput ioremap_prot cdev_init memset translate_linear_address write_physical_address read_physical_address char_class alt_cb_patch_nops dispatch_fops cpu_hwcaps ____versions arm64_use_ng_mappings get_random_bytes gic_nonsecure_priorities __arch_copy_to_user __arch_copy_from_user dev_number memstart_addr iounmap mem_section unregister_chrdev_region alloc_chrdev_region dispatch_open get_task_mm dispatch_ioctl.cm dispatch_ioctl __stack_chk_fail cdev_del kobject_del get_pid_task __check_object_size __class_create device_create dispatch_close init_module __this_module cleanup_module find_get_pid __list_del_entry_valid cdev_add _note_9 $x.99 $x.89 $x.79 $d.169 $x.69 $x.159 $x.59 $x.149 $x.49 $x.139 $x.39 $x.129 $d.29 $x.119 $d.19 $x.109 $d.9 $d.98 $d.88 $d.178 $d.78 $d.168 $d.68 $d.158 $d.58 $d.148 $d.48 $d.138 $d.38 $d.128 $x.28 $d.118 $x.18 $d.108 $x.8 $d.8 $x.97 $x.87 $d.177 $x.77 $d.167 $x.67 $x.157 $x.57 $x.147 $x.47 $x.137 $x.37 $x.127 $d.27 $x.117 $d.17 $x.107 $d.7 $d.96 $d.86 $d.76 $d.166 $d.66 $d.156 $d.56 $d.146 $d.46 $d.136 $d.36 $d.126 $x.26 $d.116 $x.16 $d.106 $x.6 $x.95 $x.85 $x.75 $x.165 $x.65 $x.155 $x.55 $x.145 $x.45 __UNIQUE_ID_depends335 $x.135 $x.35 $x.125 $d.25 $x.115 $d.15 $x.105 $d.5 __UNIQUE_ID_author394 $d.94 $d.84 $d.74 $d.164 $d.64 $d.154 $d.54 $d.144 $d.44 __UNIQUE_ID_intree334 $d.134 $d.34 $d.124 $x.24 $d.114 $x.14 $d.104 $x.4 $d.4 __UNIQUE_ID_license393 $x.93 $x.83 $x.73 $x.163 $x.63 $x.153 $x.53 $x.143 $x.43 __UNIQUE_ID_name333 $x.133 $d.33 $x.123 $d.23 $x.113 $d.13 $x.103 $d.3 DEVICE_NAME2 __UNIQUE_ID_description392 $d.92 $d.82 $d.72 $d.162 $d.62 $d.152 $d.52 $d.142 $d.42 get_random_u32 __UNIQUE_ID_vermagic332 $d.132 $x.32 $d.122 $x.22 $d.112 $x.12 $d.102 $x.2 $d.2 __UNIQUE_ID___addressable_cleanup_module391 $x.91 $x.81 $d.171 $x.71 $x.161 $x.61 $x.151 $x.51 $x.141 $x.41 $x.131 $d.31 $x.121 $d.21 $x.111 $d.11 $x.101 $d.1 __UNIQUE_ID___addressable_init_module390 $d.90 $d.80 $d.170 $d.70 $d.160 $d.60 $d.150 $d.50 $d.140 $d.40 $d.130 $x.30 $d.120 $x.20 _note_10 $d.110 $x.10 $d.100 ��        �  �  �   �4"    y� �4"       �  �      H`  �  @   &�     �   W%  K   �   �4"      �4"    �4"   �4"   �4"   5"          
2        W   .  {� f�  �  �'     
{    |�       h   �  s  �h �  5"    ~�       	   �e h   &�     W%  K   -5"    �� C5"    ��       	   �  �  H`  �  &�     W%  K   Z5"    �� n5"    ��            D  .  2  �5"    �� �5"    ��            ��               
�E  COPY_MEMORY _COPY_MEMORY OPERATIONS OP_INIT_KEY OP_READ_MEM OP_WRITE_MEM OP_MODULE_BASE OP_TEST translate_linear_address read_physical_address write_physical_address read_process_memory write_process_memory dispatch_open dispatch_close                                                                   v                     @       �                             1                                                                            (      �                              c                     �                                    ^                     �                                    �                     �                                    @                                                           h                                                           j                                                          �                                                          �                            �                             O                     �      �
                             J      @               .            )                    q      @               5      @      )                         @               P@      �      )                    ,     @                C      `       )                    �      2               �                                   5                     �                                   0      @               �C      P      )                    %                     �      X                                     @               �G             )                    l                     P      �                              �                    P                                   �     @               �H      `       )                    �                    `                                     �     @               PI             )                    {                    h                                     v     @               hI             )                    �                     p       �                              �     2               !                                   U      0               �I      �                             �      @               @J      �       )                    �   L�o   �            0K      .                                                   !      0                                                   �!      @              @               �      @               `K      0       )   #                 �                     �%                                    =                    �-      $                                                   �-                                     �                      �K                                     b                     �K      H      +   �                 P                     �c      �                             Z                     �e      k                             �                     n      �                             0��	*�H�����0��10	`�He0	*�H��1�o0�k0F0.1,0*U#Build time autogenerated kernel keya�W����`׀���� ��0	`�He0	*�H�� � e�\&[PN8V��۶�8�:>���s8y��=d�_*�޳5?$����CEs�5���ͤ�_3F�a�xQ�����̵����G�&���&��Q�h`O�� ^R��l�W1�譌�:Y�k8Bq�X7k|�� (�j�]Ik���Y���К m����6l�b��yfV�.W���"��eΘf��b
$��_�`جZ�*k�������ƪ�M0.cظ,x����dV�!�J��JΪ�\�>`O��`�����ą�d0�X����5!h�A}J��,�;	]��0�b^��T��kT#zQU�/�#f�B��[c3gf�D�D3��I�u��t�k�Ɔ��<e[���-���G�XLd�qȍH2�.T9r*�k�`�8��J���L@|�0y���C�#Ǧm�gE?��xS7$�����ш��]�{��B>�,[T7�¹|i�[��1QS��i���@<���e�{/����[7��~�rdG��5���sk-����2[$U�         �~Module signature appended~
