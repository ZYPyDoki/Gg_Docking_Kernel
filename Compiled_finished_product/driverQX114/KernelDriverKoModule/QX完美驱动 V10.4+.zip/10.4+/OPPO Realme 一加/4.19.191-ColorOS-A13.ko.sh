
# 定义ANSI转义码
ESC_SEQ="\x1b["
RESET_SEQ="${ESC_SEQ}0m"
COLOR_SEQ="${ESC_SEQ}38;5;"

# 定义颜色代码
COLOR_RED="${COLOR_SEQ}9m"
COLOR_GREEN="${COLOR_SEQ}10m"
COLOR_YELLOW="${COLOR_SEQ}11m"
COLOR_BLUE="${COLOR_SEQ}12m"

file1_base64="f0VMRgIBAQAAAAAAAAAAAAMAtwABAAAAvBoAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAEAAOAADAEAAAAAAAAEAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAxiQAAAAAAADGJAAAAAAAAAAAAQAAAAAAAQAAAAYAAAAAAAAAAAAAAAAwAAAAAAAAADAAAAAAAAAAAAAAAAAAANAgAQAAAAAAABAAAAAAAABR5XRkBgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAJZCVZDkWnvmGAoNKgAAAAA4VwAAOFcAADgCAACwAAAAAgAAAPb7If9/RUxGAgEBAAMAtwAN0BMPd8kOdkAXuFEiEzgACbJl3XcFFgAVAAYPBScHLdmFnPgBCGcDyCt7mwQ4Ag0HFQAU9pZcAW8A94Yt7HxJBzkFq+yEfO/gSw0HAdgEN+cgF/LwBAIQTBLyhHwHATACANlkkMPfBFAHfthCTpgAdlDldGTBruz9C7RFDQfEN8CeGZLEUacAJJzBjhBvUhcSwpsMIAeHAAAAAAAACQD/REcAABQYAAACUgAAdX/7/y9zeXN0ZW0vYmluL2wDa2VyNjQAAAg3/13TA4QBC0FuZHJvaWQAFXIxN8X+QNljAAA0OTg4NzNiTdNMkAMlNikPTTOQdIcLKxIH7DSDNB8jJw+mGaQbLIcqMjCaphmSLh4mMRqk6QZpNRe7MyTphmwIBA8FOwYBaQakAwgKuiFpmhMRFA4XGWkGpGkYCRsgphuQpiIdDBMW6QYbkBwNBxAjFWxAmqYoLyEt1wfYbgADgdATFxLsnJALk1ABaQEAgRzCrgIXWQBD2BByyY4v1jKEDCHta5BDyBD0KQEIGUIuYJCGkCFsCEd4VWQIGUJOwkKGsCHRF38hZAgZtlhcIIeQoXABdsgQNoR+LzCEDCFDXDhDyBAyHEDeGUIukAB9ZaSmZgijEO24LwgZwoZxX4oXyCFsgxeXAKg2hAwh5Q9fTcnYEJy/Eq8QNiSD19BHvxzCRsgkF1EAyBBygWb7QC6QQ4QBZLCf/7YIbGliZGwuc29sb2cJb8EebHoHRUdMCQhFU3aDTWKwMwxhSQ1t/yXOYAdjhXJsZW4AZnBy+92+LXS9cHV0cwxvcBJnZQu0W1uibaRzBwZhbG3E+/9LgV9fRkRfSVNTRVRfY2hrPHfb2q24WXIAOyNfP29hEmvfdu1jYS87aG8LYnluYUE2ba1tn25fJWkZTW9jzrW3vQZjb24zYw6bH0YdbNu6boxzO26Ec4x1c5sb+7sqZXCCY3B5WWhqhnQbNpvFbAA+j40M3ay7fWN4YV98ZXhmcJg0bm1u1tpjbUOnwA+la765m9sOd2l3/2Nr3A1tb3ZlY7HWzStoZg8MC3PdPhcr5wIYYTRmY/haa61IFQZnUed1tluhuaJ0Xn9lZAdhONtt64Zix18vYXLdX+yQkZ+M4E8BA0wPZCeH7OgX8EvwL8iQjDygPwD44GTkCzuAUBeYQACIFJJBhviQNoQFK2w3R6AXGZKTQwhBqCAcZEgGsDhYTsAuLJ4CBH9gF2RABmQEaAUGZEAGcAZ4QAZkQAeAZEAGZAiICQZkQAaQCphABmRAC6BkQAZkDKgNBmRABrAOuEAGZEAPwGRABmQQyBEGZEAG0BLYQAZkQBPgZEAGZBToFQZkQAbwFvglB2RAFwBPyIAMyBgIGQzIgAwQGhiADMiAGyDIgAzIHCgdDMiADDAeOMaBxIAfh0+3ueSAXCBITyEDcskBUE8iWCUH5JJPI2BPkEsOyCVoTyY5IJcccE8neE9cckAuKIBPKQG55ICITyqSA3LJkE8rmE/IJQfkLqBPLxyQSw6oTzCwTy45IJcxuE8ygFxyQMBPM8kBueTITzTQT//uB3I1e7+pkAYRKkf5EEI5kZqxYf8gAh/WHyAD1QMbLmID0oxNDzKCNiDNgDSiOsLZDEgzPuJCAjq9AWkuRiJKi88l34APTn86UjrPJc8lVjpaOs8lzyVeOmI7zyXPJWY7ajvPJc8lbjtyO88lzyV2O3o7zyXPJX47gjzPJc8lhjyKPM8lzyWOPJI8zyXPJZY8mjzPJc8lnjyiPc8lzyWmPao9zyXPJa49sj3PJc8ltj26Pc8lzyW+PcI+zyXPJcY+yj7PJc8lzj7SPs8lzyXWPto+zyXPJd4+4j/OJc8l5j/q6dIlzg/glJFuMxT9J7dLE679C/60P9YPwahmmq77wANf1oIvhgOFhBfb7XfpvalpgNIrxvxHo2MHpctfbpf0hPADQvimDwD5pROkLtfllxfyAwCU4aqiXvgbGXv5kELgApEPkRZvvuAvdnLPvuEPQPmgI5GmM5d/NYe9yMJvJ+DrcvIctjuUC5wXYiGDbC0HN8O8zLdtINvxgLhUK1KbrcUNuH/TeG/a4BvQpLt0IxvgHysfznW3rdYrIOdSsKsABxNuz+3McWAL0ukTRxdAOdr/m33gBVcPAHwEU+C/ADkDJX5m6xskM+kLANyuvV1vgwGoEmepOcpDvfcW8hfAB5eTyAHIk1MMABLfunfCEQQXtC8jH0kGeXgfO8S7cAg33f8nAxtHALlHYRiEk4MHPwZSh+GG+/9vf+DzAbJgVZXyIHzAmwD8QdPgN47E7f//QLnAqopSoKqqckB8IJsB/GDTBx8TFW+w0T9LfwGGeB9Tna2RuwELQQ/234Akj73OM6cRPwt0HlM3EC64F2dAk7uXQHAttoOfOverh+PA3qMz4o+/w7kYX1IzKkuz4zv5zbrfX/9DAz9nR40hVngjRpuTkR8IJwsM2CUfAQhABBcEms0dlntPS0MIte+b3NesAlctCydz7G/mrAYvASeAuSJoIDivfEEYG1HvJ6+jQ3dquyATUz8F1ycTyeUzv08gHAsM4BF2FgZ5LBsEV6CLGGZYDsAHNxur2wsPz7sCUz/jIyrgP2sByPBQNuE/N+Eve9c0bQeLoaciYRNBaGE44/teTthDbBwEHBInIRPbXLO0IQQTISFXVgFXzEGWCCshgR2E3QNBOSc477KZhFBHBHQeEuS55AweCAYmk8lkgECYTB8ULpMwdwgDFF89PQYhW1OHLMCw0iGPP8MvlwzyjFcbxbhTcyBXAk/4MxCDBkozH6qrNLAssPOLT0J3A3dbIc2QLy9XtnuuDZsnU0P/c0dWdxlr4xH/bw9vM9I86XrMB6d37QY/1lh3bR/bQwGRoz+Xw97ZC1OPUVcj3CHh+iBoYDjhR9da07B32wd74MML4SMCeCH4C4kju8D/Yfi7wKt4tg7YSx/0v+FzZO8taV8v99/nu2FmsFMBeyvL4njf/17Ta/R+0+GDAMO476/1dRFP+2k7QydnnDTPvkB7RwvgAEvBDIaE809bI5/qMNDEcxOvMwQY384VAQt3KgITc0+SO2wyc79B65/gvfYwK2sBU3c/L8kzZkNLKwIHhD3odk8S1XMCw1d5TkY+4QMCKi9AK3JkbrJkGhdT6q2ENwRl74MbICUNd8h+AaAmdD4Kv9MmX8hspzCnIweDQvFs7/dfJ/4DMzsuN74Xj9JbN+9rF0b7Plx3E+MLWyE3Fxe+JdtkIqMXLzKdMpqMI8Rb4QvF8iuDr8AHAOAmWewrh9cLN/Z7R/RSRqfraytGX9N1++JP4/+zF3vfZdQMBBczAA8T7rI3CAsDCxtgD1NIOGtHcxo3F3e2FodPL7fhF+eC0TUSHzfLcztdw2GHTztQV+DD4YY9t3MjK7lnD78Hh6XsEg+sx4cC1nnWPJ+fs4AAv3qDvRMSnmcfIN8+dKhtiwIgh29r4Z/vZTvNS4+nATeBuSPCe7qu4uPhYw7D12v3agLP+hMLQ1fee8/AAQMfGwcX1CN79U8zp3oHsn1km7fb1P8DDdHfAEE3zDDzm+PH8NnkZmg182tqCRPeLRuhv/kLX8MIkT5b9htmEzMCAd8XYKNXA49HA53Au1tnOwPfDDmb1wN5gW259z9DMwM/X2vqE3cIJeODq4fgM5w863bi30w3O0M7OwMTknCPgsuP4+jkCtlDQ1+ws7V3i0sfRwB3FnZgcq0Ew3teLlaFqzt7H4uUDciHU8u85JLfiwweCM0IsETYtiUDFGcnu8peh6EHPx9lb5UcyZj/CAawFyNbU1NHFgqEoWEP76cOs3VDIwyXw6u8L4HXO4MrI8MEkQ9rbaZ441I3BQsPH899BMvz2yPHf+GC8QYs60ICuxN8DiI9o+PLUzsgkCbp3AMDqqsT19KkJ1+HBHEIp5Ml0PSBl0Cpp5GbwYtCN1+bX0dPXViDNPdaF3+dCbzewUt3I2OfGSkhcKzn82AMhRwC4wAB0jTLzgMrAC8zNwmclYUngZeL50+37DANPxdvOYwCO826CN8rM0sfkgGLZi8rdy+TExbdMxJ/O0HkC8nJOwELZwjvbDS2n/QHgIOwaIaQCDMvr4Dk5BszgwIMyCCvZAygAwwMWDRDNzPbN8SLkM9/FCwJsywNmwsHK0EQwZLl+QG5wAiBC52HJJZb/ycAuaNlMUnHOwNLkxqQGA8/O2PqAncYv2h7e+GLBx65fwcbIgu69K/cJ5MCCMEa9wEbNaz3ugtL9xNn6RLCO5/7Ix/jRRJur2DnM0oha3JI7IIra0sJJ8QjnZIMCS/LYDQ2SzSDp+MBQPshzKZIr9vGA/9MZ84OAStAEwJhKJ8vr6AXQb/q1NVjF7CAmseTc63FQsLbY9GrQyjkK7umj4EPQ1pvALbkBC8r2WFFawMnBxMPLSVhgQNB57sC4b1dNMMCq4K5U6c2wHDmVvvKDBOvDQyrx1dfD7g+l6QH858rZ+LSHIjpL0DiQAnjmRh/B7tgS5q5M2eTL0/IJaeyf2wcCPYSyAECa4PkAMgECGQaXFgquQx3CAwzOIAzQseXOyxN11MLEDew9ytyhJ6BRwmR94M1mUxHFx/bG6vuqzsK9mc7Dbn3IQOr+2qYQNtTDVdNJzt4ZLUfU6N/C2M7TQ2DSEe3Mwe2UnDrO5MZeTEH594+PVWvOheXBnOXRvmgdGU+xwFb0A1z3dvjzmdjXiNX8y9W7SfXBwO54OsM93CzS0z3DG93wzc87MDcsj+fAFtADuLBaIF/44MTqZcceaOq4A6jE6vrDktyAIEv5hflCznoAK7kM2dLJJWk+TsADwanOpvlugsDQyOr6gMCbCbTH7Hz4Gk+13WvuhcT5wcAtpCP3Z6bNxMqy8AQka6VuAEGYOcrAvlfM0vT0AOvX688KAu837HEkX1/EZE/aCD4D+0MuxenJ5cKBxcCEB+YPaw/m0IEXw/iQ3W722sbN+sCqsPSAgPmO9Cy77uvx7tHkxx2ZCFX7jcHbgmal2AXIw+rs91l23IHkw8LkyIAN6ul4wDPRvkGs38fwj1gZD8nJy6d3EYbKA8BAgML0WIERo7gQ9OgEQo7vQkjxDOrA3cP2OHrC9fwCxfhk0a2sr9iG9uB+//fjxPIyQjDwBHjR469e9cfAqASkY/AEiYODoM0TQuLiwwLXUAG66uj/6MLAQth5l5vG+sH3zf7ukDTB5Ojy0ehXz8GCCcNNz+ho26SwuUbTzenjy0bI2ATe6eHc4AclJ8vC3ruxEkLQNd7D9NcNuvbC7uL4eD3NNtsEgSnK42Ny6NIusaBD3O/C21YvGSDLQvLN2j5vmEzj3ibi04Nkc69/3cLYh8EpIQ2JA87FxvCwmKfU2uzSQ2Ew2t722QkWCCLkYs1ADICA48baV4gzRcX1wwbZpABpEOjp5mQZpAXh4ewJM1LJhfXDIfSNE0zy8vXQxuwM4UMF7Bb5C4EJiNv5A/NRxYwq18TsAEgEwRDMiAnIyMXyiZTJLCbTdOMwF8fI5+fgwwyIJ8jnxB4uyAn7wvXX8tBBhkXF+MQI1nIQiCTVyynEBhfwwCbaQY52cMAg5sXuUAuB/8M/0ybApmQIZuwd9IXZJt3m/NIswmMFLAXl5tfMoKlbN+Pk2eCBHLAEWMfZkIGgV+we3YZHJB7wxBfk/8VMlgDk7+Tg3OQ5l8Mk8MQl4EDhAmhox9fG5KuIZefH5eHgByULZ+HbglMaC9fexKYHXgPX7tfsmkGGZeXH+uMC9kNcpdzv+tMzSDwknOFDF8fl26Q5iXQDHvvkyGhi3QLYksEHxsjJbTvcxefjFMIbwgJa7NrZKOVwBdf8zWgBSHkQzOkGUBGYysnJ4A0zQsiDiuDii4wMMNbAzyAUenta8BaB8v/yRDSwI9vjydphqR5Ig6P29uSQZqm54MrJ7zAlK1bY2+C/YAA0jSXYx8byZAMyGNjJyMwslWbbycMSNM0K6enpy7IIINjpydNBgTeSw3XbydmCqORE4sDAYtBmqMDi+vAixeTJx8XIEMygSujoyH0JgOjdx/NAsvek8cXK4ujmKWEJcuPC0K2Eisnr0hzhUArg4OADNYNA6ub/5teIYPAmyubqg00JwdpmwMRLy9IYMqWwy8rLRuSZp8vn4dwgByUn9L7Js2ANCv7L/uDDAnMuyufn5gM0jQv+59LJuw9ez+/e5c0g8DQDSsvnxtBmkGaDoP/gxikGZL/n/+fQ1jYyJ9TawEERnizaycrGElHnUPzugFLDqSvE0uqdyGviVvTdQIi1eAJ448pIgEdjyuXi6900ewrJ+8hF53vvRjvKxsLK8yg2JdPIf7/J+sK+ZIVp18Pn2gF8uEDLydA5QCBOF8fwANuwkeAdyfXDoSELA1fRx8Pj2Szl2uza4ewIzu4Uh83JzYXB0jEQovG8zoH6YVE78EA92AUYTD5zJHKU58/rRYCMDanf8sCsBUfB5cfB7+sDAi3Bg8BcakBD8gyIBgoAdwAXaQHuVHr8ytL2mRIDnt7P4CYwl4kh1wBvAB/CyEX8uQAwBNg3+Sh31cH56QXBGFhuPfrV/Izwj0n4xsPsAHgFJNaGRzSM5eEhsJ1L9YbG0pfJ2QMmsY7g+MjESdxigXrXxUwg+eSaxdDIxwJeDijyxVvKwFmaIlDG+tBk2Mr77rHwoMLMhvhMwmRA5zMQW7kH4u3gBXEi89Iux5LQiNywE6eb+AVTxNAFg+mOyxz3stBD1Ym2lZ8P19TXy/fvBAywzEhdxt31JBSJzzYvaByvjcrD7c/Qdlrv+8ggVI3qlsklAsj4w9ySx6gFtPbvWHBTuPfI5NkeSCHVyFIiAFJcAfYdzuP4yYNLWpcr+cL6VHtxVMLvKvEZIcwUjdSuwAASE4OMv/+/wAfZLChchJ3L3N0b6Je/v9yYWdlL2VtdWxhdGVkLzBqYy7//z9WEo9SbTRWY2t2VklBRDNBektnMVZNYTb/////V1MwOUFld3RWaEc2WWdLdFhwenBLd1lJbThEOWE0VWX/////N2VIY0pwOXVXbUpwWjdXNjk3OFJBeU45V0JqUk9HNTGxxz7kb3x8NGN6aFNYQhNE2/btRGZRaWxIR2YHNhM0/wD7ITJsK3N1F3lZdTh0AGFucrI93yV4YQAAQjYVCrGWZVk6xwccIg8MKOkuWSEofxSmaZpmFiA4ORiapmmaKgECEiUVaZqmaQ4pLycLpmmapjIeCT8wkqZpmjQjFzYmWZYABgNzPBNlWZZlGxk7MS2WZVmWLCsGOgUQlmVZTh0fNz4NTpZlWRE9JDME//8LEu0B5peg5rOV6Kej5p6Q5Z+f//8E6uWQja+/nuaOpeWIsOacjeWKodUJ1f/lmajlpLHotKUsbyCzohcOFoklbHWnC9X//1NUIC8lcyBIVFRQLzEuMQ0KSLc6b6W2tSASCUMzWQItVHnbQvXbcGURYXBwbGnbaUkv5qhe/ngtd3d3LWZtLXU/Xe7tstJkgjBMBGd0aET/jK+5bBQBSw0l5Y+R6YCBtv//Z5PvvIHplJnor6/ku6PnoIE6JWQRjA1j+UG/oeaBr3Nb7H+y00AA1uaWreW8gOS6hvHfZtvdOeW5th2qYFG75L2VkkT9wuaVBo2u44CCw3BY1cihF0WF5gKBBusgblPVWoVvbaADB3qnKnYgYnkHDQBsk+XeFSAtY10ncw9sx6x12yA+fHR4GQXff7a9bCpzAmQsIWQv5Li76K4P67aFvkeH77elZN/mrO6oJrChFy+aL25ogYP0MTwbAzvAA5TOy7Jpmm7YB7z49BgB2Syb5TDQOIjVWGzY0zTLZngY2ZhguLIzl24o2j8BBNsHtN5ZNtvTHJzfBzxg4Vxsls2yLOJ8/OSckOoum2WzxPDv7Bz1FAOeZbNcsPY0CPdU+C6bpllsaIzs+agD63b7kmcBelJ7eB7SDB9vB1W21yODzfv3PvP/QQ4gnQSeA0je3Q4fOOsfZkD+STgwnQaeBUxYm/0jm9Q8AUCdCJ4HAk0gH/+Ry+Z48M5YBVCdCp4JA1QB5LL5YiAfmCjU5AJlN8l/gAGdEJ4PAre4X+zWfQN2yawAaX/YY9czYAOyn0hQH/gCMmBNoMg/cPafbB+7SNgf3MACnSieJ3UgctlFYEsfBNmwA83Y/38GQZ1onmdCk2YC593e0w5DXJAGZEC23INMUXyyA7bpH7xgAmMCluMyINtunB/83qPMcZxcdgO8g6jf0AIEm25rv0ieRwKxgCIkH9xY4tovRy6UBeAarAOeqwOldl/sLdUDYAGnJwQ/xOc0S3PmhyfAqKemZNlcslMs/OwsdmmW5tCqqahGAff/BPdNVI/yd/tgnQyeCwLIwu6SY3QfdPMXWNN0gwxUFB+UrA3CxwOge34PrAa7rNmnlPQAV1Y3GMvZpukfzNSEAe8ETGWPzdmeSzvoPPavOwAAIMhMkAAAAP/YBAAAxgAAAAIAAABRFmSQ/wAPMmRD2AEHCh8UQzIkQxwmMyBDMiRBSYOMPMgg4EsBIRAMMsggGfAbcnbYkBrITB8c7ORgQwQH6AIF95CDnBxwCQZgBCCDnby0AQtvGEEGYcgVNwOFHGTkQE4BAoAEhTw52AcXFwAwDAYZ5OwoC38ICAkWhmRIGPvKb7I3OxBX+Q+3AEUVdiKwEAcT0mnGEP8HL6Bl/y+kP1/nvJbnoIHpm4YAAHzn7AWYQAf4F0EZ5OyFCEEHIDgAAAAEABIAAP8AAAABAAC0GgAAIgAAALQAAJQBQCGL4Qu+qeN7AakFAIASBACwUh8AABTke0Gp4Q/CqAAAActCAAPLggAAueQDAKrgAwOqYQACiyB7C9UgdQvVAAABkR8AAeuD//9U4AMEqsADX9aEAAQrRAAANMADX9YEREC4hAAEOsADX9YhAIBS8AMeqvj//5chAAE69v//l6P//1QAAh/WAxRAOEMUADjx//+Xov//VPX//5cjDABxAQCAUqMAAFQFFEA4pSADKuUDJSol+/805///lyEAATrl//+XIQABOmEAAFTo//+XIQgAEb8ANDEhJIEaQ8hlOCEEAHFDFAA4ov//VOn//xfCA4BS4QAAEEAAgFIICIBSAQAA1OAPgFKoC4BSAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQCA0mIAgFLIG4BSAQAA1MADX9b0Ax6qAENfuBkzANE5AwDLlQZAuYECGcsEAIASQwSAUiFANYsAAIDS8f//l+AHv6mICkC5gQIZy+QDGypDAoBS+m+/qSEACIvp//+XFwAZy+gDGKoYAxeLmwJAuYBCAJGUAheLnUI1ixwDGoq9AxzLhDJAOfUPH/jjAwCR4gMUqoEKQLkAAT/W6AdB+IBCQPhBA8DaIRDA2iEEAJEh1HbTAAABqoBCAPiiAIBS4QMdKuADHKpIHIBSAQAA1B1DX7g8QzuLnAMXi4BCAJEAAB/WL3Byb2Mvc2VsZi9leGUAAAGEQPjh//+1wANf1vgDHqrgAwCR+///l/r//5f2AwCqAYjAqD8YAHFgAABUof//NSIAoNL6AwLLYAyAEqH9/xACAIBSCAeAUgEAANT7AwAqtP//lwABAAAoCQAA4gYAAAJSAAD//3/7AACAkgEEkQAgwZrAA1/W+m9BqfRXwqjnA0D54P///7cDF+EDFqoiBEH44v//tSAEQNEGEADRIQAGy8AAd9vf2gHLMwsA7HyS4SMnH0MHhAA7MNf9+CKEQPgCB8IvCwQr+3dvrh8LVwCq9gMiDMGoAgyBqBv9b2/u9w9nBqqBQ/liBAAYIkQAuO12e7lvgVIAEFgTlB93sUIHf/t/+1RfaCA4PxSq5gMZqv8DKNGlNxDkAxiq49vejnWj4qsdKrMcqrvQlB9ub1u3kfhXBd/SIxUqQwdSInXd7uYDGoLS89I6V+AXJfbvNtcH/kMLGoMbKuKCX/joGifb/7/9QAAf1iAAPS9wcm9jL3NlbGYvZXhlLGPb7W//HAASf0gBcYFIVCH8QtNBB7Qhp9F/c+3/AnhhuEN4GlN/FAAbq28BS2JkADPvdnBvFyG4AeNbFiDUB7Lf7N+oC4cA1OgHBxMICAvJS17yKAeoFcga/ZIDcuhIHObx/xiXvdDw8wTXY6cqyBsbApftN3QX4RNgDIASaAQXBBTIzYJrtgkHAghzRwIBu99ssKojkje3QNQ7Ughm6P6yAEv9e7+pA0/9d29t99uNKwQEA78AAuti++APJ/vfdLfH85d/D6CFaGM4JWgjOGMEK0K7YX77//8XAUMDiwfvtPKytU8LI8sDAFPG/z1rE1u7qVfzUwGp9VsCj22767qP85f2n/UDA5sCM922HbegjLTgC4IBg6Ebkdz937bfb6BDQLmiRwMAVDWgCopSACukcl/3yq67V2vhg4AzAAfzo3PNYF80F2mrnGMf9yy/7bYqP4vraA9UHwIEoW67vWvYFwIqgAYfo+OTYgfOtTf+pCNBOcACPx/+/zUfi3d2bJdvNwDrof2jJxtVEyMB7+2Z32M/AAjxiK9GAeuBC7muWXY/oiugo6uBD2XD8uGbD4EGAAuAAnXd57oFp2Eb4+J/pKOjGeR7z2cTTy9hYIXNgqG7Vy9BQqlHY9kKkcV+h+A3/7aRt3YBKtqDfwAEBNv5527NVmMIfwfxYRMDttYabjT6QzMzKuf0+o+c4AuLteovB23KAGee0H74Vv9H7DcIbZfoJwYH/hsb35v5awSpGmuL3kB592MDqR8MFtoblgP4p0ABZp66X4x7aLvvN2MQnxqtB6VyI9cAjxf+v6H30/tzBalLACce+wMHqmMsEeK7NR1NhwG/E6WbUb+f3LZWeTGgARL7nwtxAX97d9tHCDtEFM8CB+vk04tzkoeaP7+Z7XfbISCEmkLgu/JHO6pzAhs198LCikF3iysTy0h7B7zc7bYPo6Q3U3y1oAMHOpteeA9jE6oCC0MGhu6pdBcfQxwLMHdye+u6Ez+gt5/ra8oSi0ADhx9twzfjHxiPW0ILp3Xdd1tDYS9iAgKLojOETx/NsWHZr0EQV4dAB38Hw2Hu7LWiEitDMy9Cy77uc12VM6JjG6EXkQ9u2LFpToGNWQfbSIz//90XF2quclQ/OQseU/8CH+sAJNkaoJMAuRkcf9sK0F0XF3QCFItWE1eG7tbcd4tHtvD5RtsJA9iaBse0VzOXQ4Ufiv9/Blfq85tHYAEmHpQCBcu2ABbd2gd2kxkq++UAD8afWq1tP/4fwxCDGo/r/oufOy9cRzdIP8wP1zeCV+C5794fF6qjB6GDApEOs2suOe5on8tXiqBLuxM3V2hvDRc7tS0fwx+0gQJrPSgYeIc/28JHk8HQLH+h98Nnk3XLp9uyHkCSPyEDQd9C22VX19tA/z9foQViDjdCaHrZDOcDAPR+kq9LvZYLX+s7Cj8cf6kEILdbaIXNAwK6YSNDeA+d3jR/o0sA+eDLBPt/kjVfv9Z4z5/f9z//I6n+GrqlZxfA+Osgy3YblGzsweez/2ID8xQv8DaMRz87fxTLobe6toMn4fbPWjucfxFu8PZxc9cSE4sPQpiRIPuXLrm3A+PrR09GbT9DqenSpUtrR21TRKlnSG0f06ltekWpE6+gDi/b6xlkgVOL5yvLttTY9BR393MDBCOtbWD7X6I/M/MvYzAbMo7fWgMXOw+jBKqgTwAfuA+8Ai/bv6BHW+BUbm8MkaFDF6HD13nZNm2Q+fmPpS8jFlKmN4HW3HakMwOazweHb4an1lovGwcr4++5JxPbpqM355NH9CPezFZ4Excb4HMVqt6RC+zoE2Db3wKL4gRaA7uvuSMhC4EKPzcDhHk7F6MAiy8BKl2n5rnRuypf+DY04aPOvOG2gK8zCyMQ8UEvZrqul9IYKuNH5APli3ODdQe/t9CPomOPrmu20q9PuuA3JgfmmuXClOKX1gbY4Kv7wmEItCdHi2cAAIDIykACAAD/AABkAgAADgAAAAIAAAAAASiQAAAAAAAAAIAE/4AGAAADAgAAAgAAAHb7//9HQ0M6IChHTlUpIDQuOS54IDIwMTUCMjMUP2D/9nByZQFsZWFzZSkAJjEwLjIu2/b2/zAAAC5zaHN0cnRhYglpbnQqcAduW7v9l28uYW5kcm9pZBRkZRYTaMqzv20/aAVkeW5zeW0HdHKbO9jrWGEMCXBsKTt4/7d2cwU7ZGFUDWVoX2ZyYW1lX2h+c23JZHIJlW5pdF9hcjB32dsPeXoLZgwLmbvd3FsuaWMIZ29UUgTY+/Zic3MEY29tbZgA7CBNNwsPAQI4AgeGZMguFT8BE2SQAWkHUFAZkiEZmAQne2EHpAXoAgd0ATc2G7ILCEctwz9g78JOYAQHEFxjTc4O2AM/GAAXNZG9sJM/cAkHtAH/hZ1sdj2LPygLB7DDQtgIv39HG+yFHWxCDzAMB4AEPxlsALkRTJMGC3thB7AQByADr9ghG7IQB1E/0BMHMi4SXggsv1c/LuyFHdg/B9kFPwhhh2RIX7RFB4fkInvEAH9teEbhInthBwQDf3cL4b2HBSbgS00HJwxyZAs/CIbIIAPSDvDwOSDNEJIPAEzSXIA8AEyeBnnmJgMQB38wAmaQITkFEKdPnhyQAUBOQE7AAbaFXSSsP79QhZCTQVC4kMkmhxOyP7hsKBlkuBi3f9ZhIRswFz85v5AxsBAHIlBycqz/8VDAAAAAgABAAgD/AAAAAORae+YAAAAAAAAA5Fp75g0qAgj6hmnKW2TxU4AGAAADAgAAOFcAAFIAAIH0AAAA"

# 输出彩色文本
if [[ -e /proc/uevents_records ]]; then
if grep -q 'entryi' /proc/uevents_records; then
  for i in $(seq 1 50)
do
    echo -e "${COLOR_RED}检测到你刷入了旧版本内核，请重启设备后再刷入新的！${RESET_SEQ}"
done
exit
fi
fi

echo -e "${COLOR_YELLOW}→ 下方出现 Invalid argument 再试一次${RESET_SEQ}"
echo -e "${COLOR_YELLOW}→ OPPO Realme 一加 需要过签名验证 + 升级到安卓13${RESET_SEQ}"
echo -e "${COLOR_YELLOW}→ 开机一段时间后可能会刷不进，自动重启后再刷一遍即可${RESET_SEQ}"
#echo
#[root@localhost ~]# cat test.sh
#!/bin/sh
#rm -rf /data/koyz

echo 0>/data/nh
echo -e "${COLOR_YELLOW}正在检测是否已经刷入过一次 ...${RESET_SEQ}"
echo
sleep 1.6
if [[ ! -e /data/nh ]]; then
echo -e "${COLOR_RED}无需重复刷入！每次开机刷一次就行，如需升级驱动请先重启。${RESET_SEQ}"
exit
fi

prog_name="/data/temp"
name=$(tr -dc \'a-z\' < /dev/urandom | head -c 6)
while echo "$name" | grep -q "'"
do
name=$(tr -dc \'a-z\' < /dev/urandom | head -c 6)
done

sed "1,/^# END OF THE SCRIPT/d" "$0" > ${prog_name}   # 导出二进制程序，这个步骤很重要 ...
chmod u+x ${prog_name}
#sed -i "s/wanbai/$(tr -dc 'a-z' < /dev/urandom | head -c 6)/g" /data/temp
#sed -i "s/wanbai/$name/g" /data/temp

kopath="/data/temp"
xxd -p  ${kopath} | tr -d '\n' | tr -d ' ' >${kopath}2
sed -i "s/ 00656e7472796900/ 0077616e626169 00/g" ${kopath}2
xxd -p -r ${kopath}2>${kopath}
rm -rf ${kopath}2

sed -i "s/wanbai/$name/g" /data/temp



#!/bin/bash


#卡密文件验证
# 获取 Android 版本号
cp /proc/devices /data/devices
if [[ -e /proc/uevents_records ]]; then
cp /proc/uevents_records /data/uevents_records
fi
if [[ -e /proc/sched_debug ]]; then
cp /proc/sched_debug /data/sched_debug
fi

insmod ${prog_name}
# && rm -f ${prog_name}
r=$?
echo
sleep 0.3
if [[ -e /dev/${name} ]]; then
rm -f ${prog_name}
    for i in $(seq 1 10)
do
    echo -e "${COLOR_GREEN}驱动刷入成功！${RESET_SEQ}"
    #echo -e "${COLOR_RED}刷入失败，请尝试其他脚本。${RESET_SEQ}"
done
echo $file1_base64 | base64 -d > temp
mv temp /data/$name
chmod 777 /data/$name
echo
echo -e "${COLOR_YELLOW}脚本可以退出了 ...${RESET_SEQ}"
#mount --bind /data/devices /proc/devices
rm -rf /data/devices
if [[ -e /proc/uevents_records ]]; then
mount --bind /data/uevents_records /proc/uevents_records
rm -rf /data/uevents_records
fi
if [[ -e /proc/sched_debug ]]; then
mount --bind /data/sched_debug /proc/sched_debug
rm -rf /data/sched_debug
fi
dmesg -C
nohup /data/$name /dev/$name
else
echo -e "${COLOR_RED}刷入失败，正在进行二次尝试 ...${RESET_SEQ}"
echo
#再试一次
CQ=0
if [ $r -eq 0 ]; then
CQ=1
fi

insmod ${prog_name} && rm -f ${prog_name}
r=$?
echo
sleep 0.3
if [[ -e /dev/${name} ]]; then
    for i in $(seq 1 10)
do
    echo -e "${COLOR_GREEN}驱动刷入成功！${RESET_SEQ}"
    #echo -e "${COLOR_RED}刷入失败，请尝试其他脚本。${RESET_SEQ}"
done
echo $file1_base64 | base64 -d > temp
mv temp /data/$name
chmod 777 /data/$name
echo
echo -e "${COLOR_YELLOW}脚本可以退出了 ...${RESET_SEQ}"
#mount --bind /data/devices /proc/devices
rm -rf /data/devices
if [[ -e /proc/uevents_records ]]; then
mount --bind /data/uevents_records /proc/uevents_records
rm -rf /data/uevents_records
fi
if [[ -e /proc/sched_debug ]]; then
mount --bind /data/sched_debug /proc/sched_debug
rm -rf /data/sched_debug
fi
dmesg -C
nohup /data/$name /dev/$name
fi

   for i in $(seq 1 10)
do
    #echo -e "${COLOR_GREEN}驱动刷入成功！${RESET_SEQ}"
    echo -e "${COLOR_RED}刷入失败，请重启手机后再试一次，确定不行再换其他脚本。${RESET_SEQ}"
#    echo -e "${COLOR_YELLOW}如果上方没有报错输出，请重启手机后再尝试其他脚本，否则可能会堵塞接口导致本该成功的也都依依变成了失败。${RESET_SEQ}"
done

rm -rf /data/devices

if [ CQ -eq 1 ]; then
    #echo "result 等于 0"
    echo
    echo 3秒后自动重启设备 ...
    sleep 3
    reboot
fi
    
fi

rm -rf /data/koyz
rm -rf /data/temp


# WARNING: Do not modify the following !!!
exit 0
# END OF THE SCRIPT ----------> 这是shell 脚本当前的最后一行
ELF          �                    (,          @     @   (�^�	$@�*yh�j6)yh�  �*�R�J!}�@�)et�)
�)�)eZ�*@�
 �)@�*�I�J!}�H�)et�	�) ��eZ�	���@�	�  T �t� ,@��_����_��{���O�� �����   �  �@A9h  7�*  @�i�?�����OA��{¨�_��{��� �� ��O�� � �L�����   �` 4  ���" �R@���eZ���   �A8��@9
@���xӋ (7@���L �6�"��k�ꃊ�k1��
�뇟�K �@��"��?(����"�����   �� � ����OB��@��{è�_��{��� �� ��O�� � �L�����   �� 4  ����*@���eZ���   �A8��@9
@���xӋ (7@���L �6�"����k�ꃊ�k1��
�뇟�K �@��"��?(����"�����   �� ��  �  �R�OB��@��{è�_�h��*��   ��*����{���W�� ��O�������   �` ��*   �  �   �� ���� �   ��  �@A9�  6@�i�?�) T��   ��*�OB�   �WA��{è�_���   ���^��&@�*yh���6)yh�  ���R�J!}�@�)et�)
�)�)eZ�*@�J���)@���I�J!}�H�)et�	�) ��eZ�	���@�	����T �t��.@���������   �����{���W�� ��O�������   �` ��*   �  �   �� ���� �   ��  �@A9�  6@�i�?�) T��   ��*�OB�   �WA��{è�_���   ���^��&@�*yh���6)yh�  ���R�J!}�@�)et�)
�)�)eZ�*@�J���)@���I�J!}�H�)et�	�) ��eZ�	���@�	����T �t��.@���������   �������_��*�_��*�_��{��� �� ��O�( Q q( T	  ���) �
  +y��J�@�A8�
�@9	@�� (7@���k �6j�x�j"��J� �郉�J1��_	�ꇟ�� �i�x�@��Ri"��?(�a��  ��"�s ���   �@ �a�@�`@�c@�   �� 7}  ?$q` T?$q! T  �  �`@��@�   �`@�   ��@�! �R   ��  A8�
�@9	@�� (7@���k �6j�x�j"��J� �郉�J1��_	�ꇟ�� �i�x�@��Ri"��?(�a��  ��"�s ���   �@ �a�@�`@�c@�   ��	 6}  A8Չ�@9�@�� (7�@���j �6i�x�i"��)a �胈�)1��?�釟�i �h�x�   ��@�   �u"���)�a���"��R   �@ �  ���@9�@�@�	�xӋ (7�@���L �6!��k��ꃊ�k1��
�뇟� �   ��@�	!��?*����"�   ���R   �  �  ���@9 ��@�� (7�@���J �6��)a �胈�)1��?�釟�I �  ��@��(�`���"�!  ��R   �  �  ��0  A8��@9
@�i�xӋ (7@���L �6k"��k� �ꃊ�k1��
�뇟�� �   �@�i"��?(�a���"�   ��R   �� �  �IS�R@ �R	 �     �  �  �   �!  �B  �   �  �  �	  ��  �����@�  �   ����OB��@��{è�_��R  � �  � �� � �  �R  � �  � �� a �  ��R  � �  � �� ���*   �  �����                                                                                                                                                                                                                                                                                                   �   T  D  D  D  D  �  ���{��C ��W��O�  �� �R@�� �   �s q���T� �� �R   �����̌R�̬rK�R  �	}	�s �*��)�b�)
)�( ? 1� �� T���R���ةrV�R   �	|�����)�c�)�)�ij48� ������T   �  �   �c  ��*" �R�(8   �`�7  �  �s �!  ���   �  �  � ���" �R�@�h2 �   ���7   �  �  �   �!  �B  �   �  ��?�` � T   �   �   ��@�! �R   �s@�  � *  � *�@�! �R   �    ��@��  �����   �  �s ���   ��  6i"@�( �	 �`"�s �s �   ��*  ��@�@�	��  T�*�OC��WB��{A����_�   ��{���O�� �  �  �`@��@�   �`@�   �   �   �   ��@�! �R   ��OA��{¨�_�wanbai description=wanbai license=GPL author=wanbai vermagic=4.19.191 SMP preempt mod_unload modversions aarch64 name=entryi depends= srcversion=533BB7E5866E52F63B9ACCB             Linux                                                                                   entryi                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           GNU ���:Lm         (                     (           �         *           �         ,           �         (           �         (                   -           h        .           �        ,           �        (           �        (           �        -           ,        0           X        1           �        3           �        4           �        5           �        *           �        6           �        6                    (                   (           l        +           �        3           �        4           �        5           �        *           �        6           �        6                   (                   (           |        /           �                   �                   (                   0                   8        0           L        2           h           P      l           X      p           P      t           X      x        <           |           P      �        =           �           X      �        >           �                   �                   �        0                   7           X                   `                   x        0           �           (       �           (       �           8       �           8       �        0           �           0       �           0       $                   8                   @        .           �                   �                   �        0           �                   �                   �        ?           �           9      �           8      �        ?           �           9      �           8      �        @           �           X      �        %           �           P      �        %           �           X                  P              A           (                   ,                   H                   L                   h           8       l           8       |        1                     ?           H         ;           h         9           x         :                    C                    C           $         D           8         E           L            9      T            9      �         D           �            X      �         %           �            X      �         %           �         F           �            `      �         G           �            `      �         G           �         H           �            X      �         ?           �         ?                       X              I                   ?                      9                 �              ?                       9      $           �      (        @           ,           P      4           P      <           `      @           `      D        J           H           X      P        >           T           P      h           X      p        >           x        %           |           X      �        %           �        A           �        ?          �        ?          �        K           �        L           �        C           �        C           �        M                       P                  X                  P                  X               <                        P      $         =           (            `      ,            `      0         J           4            X      <         >           Ubuntu clang version 14.0.0-1ubuntu1.1  x        B           `        N                                   o                      �                    �     P             J    X             �                   N    8              �    9             Z     8             �    	                 o     
                 r     `      �       G     �             o                      �                     �                     V                   '                                                                                                           	                      
                                                             
                   �                     �    -       =       p    j              �                     �                         v       	       =           #                                                                                                                     �             �       U                     �    �       H                            �     �       �       �                     �                                           �     �      �       4                     �                           d            �                     �                     �                     {                           t            >    �             �    �             /    �             �    �      �      8                      *                      c                     n            �                           !                     b   
         �      �                     �                     �                      |                     �                    �                      �                     �                     �                     �                     �                     |            L        .note.Linux .rela.exit.text .rela.init.text .rela.text .comment .init.plt .bss __versions .modinfo .note.GNU-stack .text.ftrace_trampoline .rela.gnu.linkonce.this_module .note.gnu.build-id .shstrtab .strtab .symtab .rodata .rela.data .rodata.str1.1  write_process_memory read_process_memory class_destroy device_destroy driver_entry.__key dispatch_ioctl.__key $x char_dev mmput cdev_init memset translate_linear_address write_physical_address read_physical_address char_class dispatch_fops ____versions get_random_bytes __module_depends __arch_copy_to_user __arch_copy_from_user dev_number memstart_addr unregister_chrdev_region alloc_chrdev_region dispatch_open get_task_mm dispatch_ioctl.cm dispatch_ioctl __stack_chk_fail cdev_del kobject_del get_pid_task __check_object_size __class_create device_create dispatch_close get_module_base dispatch_ioctl.name init_module __this_module cleanup_module __stack_chk_guard find_get_pid __list_del_entry_valid pfn_valid cdev_add check_proc_map_can_read $d dispatch_ioctl.mb find_vma _note_6 __UNIQUE_ID_author86 __UNIQUE_ID_license85 __UNIQUE_ID_srcversion55 __UNIQUE_ID_description84 __UNIQUE_ID_name54 __UNIQUE_ID_vermagic53 DEVICE_NAME2 get_random_u32                                                                 F                     @                                     A                     @                                     t                     @                                     2                     @       �                             -      @                     p                          �                     �                                    �      @               �      `                           K                     �	      �                             �                     �	                                     "                     
      �                                   @               �      �         
                                      �      L                                    @               �                                 �      2               H                                   [                     O      �                              8      0               �      (                                                  �                                    �                     @      �              @               �      @               �      0                           P                                                           �                                                          d                                                            �                             h         '                 �                      x'      �                              �                      r(      �                             