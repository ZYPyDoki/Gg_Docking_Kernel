#!/system/bin/sh

# 定义ANSI转义码
ESC_SEQ="\x1b["
RESET_SEQ="${ESC_SEQ}0m"
COLOR_SEQ="${ESC_SEQ}38;5;"

# 定义颜色代码
COLOR_RED="${COLOR_SEQ}9m"
COLOR_GREEN="${COLOR_SEQ}10m"
COLOR_YELLOW="${COLOR_SEQ}11m"
COLOR_BLUE="${COLOR_SEQ}12m"

BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

clear
echo -e "${COLOR_GREEN}ParadiseKMA${RESET_SEQ}"

# 检查是否以root权限运行脚本
if [ "$(id -u)" != "0" ]; then
    echo -e "${COLOR_GREEN}错误提示:${RESET_SEQ} 请使用root权限运行此脚本。" 1>&2
    exit 1
fi

ERROR_MSG=$(insmod ./5.15-Pixel.ko 2>&1)
if [ $? -eq 0 ]; then
    for i in $(seq 1 100); do
        echo -e "${COLOR_GREEN}内核模块加载成功!!!频道@ParadiseKMA${RESET_SEQ}"
    done
else
    echo -e "${COLOR_RED}驱动加载失败，请重启手机后再试一次。${RESET_SEQ}"
    echo 10秒后自动重启设备 ...
    sleep 10
    reboot
    exit 1
fi