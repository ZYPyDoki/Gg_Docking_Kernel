#!/system/bin/sh

MODULE_PATH="./6.6.ko"

# 检查文件是否存在
if [ ! -f "$MODULE_PATH" ]; then
    echo "Error: Module file not found: $MODULE_PATH"
    exit 1
fi

# 加载模块
insmod "$MODULE_PATH"

# 检查结果并显示日志
if [ $? -eq 0 ]; then
    echo "Module loaded successfully"
    dmesg | tail -30 | grep -i paradise
else
    echo "Failed to load module"
    dmesg | tail -50
fi